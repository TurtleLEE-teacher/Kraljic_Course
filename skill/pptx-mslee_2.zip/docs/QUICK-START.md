# Quick Start Guide
**pptx-mslee 교육자료 생성 도구**

5분 안에 첫 번째 교육 과정 PPTX를 생성하세요!

---

## 🚀 빠른 시작 (5분)

### 1단계: 의존성 설치 (1분)

```bash
cd ~/.claude/skills/pptx-mslee
npm install
```

설치되는 패키지:
- `pptxgenjs` - PPTX 생성 라이브러리
- `handlebars` - 템플릿 엔진
- `@ant/html2pptx` - HTML→PPTX 변환 (v2.0 핵심)
- `sharp` - 이미지 처리 (html2pptx 의존성)
- `chalk` - 터미널 색상

**중요**: `@ant/html2pptx`는 이미 `html2pptx.tgz` 파일을 통해 설치됩니다.

### 2단계: 샘플 데이터 확인 (30초)

```bash
cat data/session1-scm-kraljic.json
```

샘플 데이터 구조:
```json
{
  "course": "전략적 재고운영 및 자재계획 수립",
  "session": 1,
  "slides": [
    {
      "id": 1,
      "layout": "cover",
      "data": { "title": "...", "subtitle": "..." }
    }
  ]
}
```

### 3단계: PPTX 생성 (30초)

```bash
node scripts/generate-course.js data/test-sample-2slides.json --debug
```

성공 메시지:
```
=== EduPptxBuilder - Course Generator ===

Processing: data/test-sample-2slides.json
EduPptxBuilder v2.0 (HTML-based) initialized
  Theme: strategic-edu

Generating PPTX...
Course: pptx-mslee 스킬 테스트
Session: 1
Total Slides: 2

✓ Handlebars helpers registered
✓ Handlebars partials registered: common-styles, header, footer
✓ HTML generated for layout: cover
✓ Slide added: cover - pptx-mslee 스킬 테스트
✓ HTML generated for layout: content-2col
✓ Slide added: content-2col - 개선 전 vs 개선 후
✓ Converted slide 1/2
✓ Converted slide 2/2
✓ PPTX conversion completed

✓ PPTX saved successfully: output/test-sample-2slides.pptx
  Total slides: 2
  Warnings: 0
  Errors: 0

=== Summary ===
Success: 1
```

**v2.0 변경사항**:
- ✅ HTML 기반 생성 시스템
- ✅ Handlebars 템플릿 자동 컴파일
- ✅ html2pptx를 통한 고품질 변환
- ✅ 텍스트 오버플로우 자동 방지

### 4단계: 결과 확인 (1분)

생성된 파일 위치:
```bash
ls -lh output/session1-scm-kraljic.pptx
```

PowerPoint에서 열기:
```bash
# Windows
start output/session1-scm-kraljic.pptx

# macOS
open output/session1-scm-kraljic.pptx

# Linux
xdg-open output/session1-scm-kraljic.pptx
```

---

## 📊 지원하는 레이아웃

현재 구현된 3가지 레이아웃:

### 1. Cover (표지)
```json
{
  "layout": "cover",
  "data": {
    "title": "1회차: SCM 개념과 Kraljic Matrix",
    "subtitle": "전략적 재고운영의 기초",
    "course": "전략적 재고운영 및 자재계획 수립",
    "date": "2025",
    "instructor": "강사명"
  }
}
```

**특징:**
- 그라디언트 배경 (세션별 색상)
- 중앙 정렬
- 48pt 굵은 제목
- 28pt 부제목

### 2. Content-2Col (2단 본문)
```json
{
  "layout": "content-2col",
  "data": {
    "title": "슬라이드 제목",
    "sessionBadge": "1회차",
    "leftTitle": "왼쪽 제목",
    "leftContent": "왼쪽 내용\n(\\n으로 줄바꿈)",
    "rightTitle": "오른쪽 제목",
    "rightContent": "오른쪽 내용",
    "footer": "전략적 재고운영 교육",
    "slideNumber": 3
  }
}
```

**특징:**
- 좌우 2단 구성
- 각 단마다 제목 + 본문
- 세션 색상으로 제목 강조
- 헤더 + 푸터 자동 추가

### 3. List-Bullets (불릿 리스트)
```json
{
  "layout": "list-bullets",
  "data": {
    "title": "슬라이드 제목",
    "sessionBadge": "1회차",
    "introduction": "선택적 소개 문구",
    "items": [
      "첫 번째 불릿 포인트",
      "두 번째 불릿 포인트",
      "세 번째 불릿 포인트"
    ],
    "footer": "전략적 재고운영 교육",
    "slideNumber": 2
  }
}
```

**특징:**
- 최대 6개 항목 (6x6 규칙)
- 세션 색상 불릿
- 선택적 소개 문구
- 자동 간격 조정

---

## 🎨 세션별 색상

각 회차마다 고유한 색상이 자동 적용됩니다:

| 회차 | 주제 | 색상 | Hex |
|------|------|------|-----|
| 1회차 | SCM & Kraljic | 청색 | #1a5276 |
| 2회차 | 병목자재 | 주황 | #e67e22 |
| 3회차 | 레버리지자재 | 녹색 | #27ae60 |
| 4회차 | 전략자재 | 보라 | #8e44ad |
| 5회차 | 일상자재 | 회색 | #95a5a6 |
| 6회차 | 종합정리 | 밝은 청색 | #3498db |
| 7회차 | 케이스 스터디 | 빨강 | #c0392b |

JSON 데이터에서 `"session": 1`과 같이 지정하면 자동으로 해당 색상이 적용됩니다.

---

## 🛠️ 고급 옵션

### 배치 처리 (여러 파일 한 번에)
```bash
node scripts/generate-course.js data/*.json --batch
```

### 출력 파일명 지정
```bash
node scripts/generate-course.js data/session1-scm-kraljic.json --output my-presentation.pptx
```

### 디버그 모드
```bash
node scripts/generate-course.js data/session1-scm-kraljic.json --debug
```

디버그 모드에서 출력되는 정보:
- 각 슬라이드 추가 로그
- 색상 적용 정보
- 경고 메시지 상세
- 성능 측정

### 품질 보고서 생성
```bash
node scripts/generate-course.js data/session1-scm-kraljic.json --report
```

생성되는 보고서 (`output/session1-scm-kraljic-report.json`):
```json
{
  "totalSlides": 5,
  "warnings": [],
  "errors": [],
  "slideTypes": {
    "cover": 1,
    "content-2col": 2,
    "list-bullets": 2
  },
  "timestamp": "2025-01-03T10:30:00.000Z"
}
```

---

## 📝 데이터 파일 작성 가이드

### 기본 구조
```json
{
  "course": "교육 과정명",
  "session": 1,
  "title": "회차 제목",
  "totalSlides": 5,
  "description": "회차 설명",
  "slides": [
    // 슬라이드 배열
  ]
}
```

### 슬라이드 구조
```json
{
  "id": 1,
  "layout": "cover|content-2col|list-bullets",
  "data": {
    // 레이아웃별 데이터
  }
}
```

### 줄바꿈 처리
- `\n` 사용: `"leftContent": "첫 줄\n두 번째 줄"`
- Bullet 리스트는 배열로: `"items": ["항목1", "항목2"]`

### 특수 문자
- JSON 이스케이프 필요: `"`, `\`, `/`
- 예: `"제목: \"SCM 개념\"`

---

## ⚠️ 문제 해결

### 의존성 설치 오류
```bash
# Node.js 버전 확인 (18.0.0 이상 필요)
node --version

# npm 캐시 정리
npm cache clean --force
npm install
```

### PPTX 생성 실패
```bash
# 출력 디렉토리 권한 확인
ls -ld output/

# 디버그 모드로 재시도
node scripts/generate-course.js data/session1-scm-kraljic.json --debug
```

### 폰트 문제 (Noto Sans KR 없음)
- Windows: [Google Fonts](https://fonts.google.com/noto/specimen/Noto+Sans+KR)에서 다운로드
- macOS: `brew install --cask font-noto-sans-cjk`
- Linux: `sudo apt-get install fonts-noto-cjk`

### JSON 파싱 오류
```bash
# JSON 유효성 검사
cat data/session1-scm-kraljic.json | jq .

# 문법 오류 확인
node -c scripts/generate-course.js
```

---

## 📚 다음 단계

1. **템플릿 커스터마이징**
   - `templates/education-course/styles/theme-strategic-edu.css` 편집
   - 색상, 폰트, 레이아웃 조정

2. **추가 레이아웃 개발**
   - `templates/education-course/layouts/` 디렉토리에 HTML 파일 추가
   - `scripts/edu-pptx-builder.js`에 메서드 추가

3. **품질 검증 도구 사용**
   - (향후 구현) `node scripts/quality-checker.js output/session1.pptx`

4. **전체 교육 과정 생성**
   - Session 2-7 데이터 파일 작성
   - 배치 생성으로 72장 슬라이드 자동 생성

---

## 💡 팁 & 트릭

### 1. VS Code에서 JSON 자동 완성
`settings.json`에 추가:
```json
{
  "files.associations": {
    "**/data/*.json": "jsonc"
  }
}
```

### 2. npm 스크립트 활용
```bash
# package.json에 정의된 스크립트
npm run generate data/session1-scm-kraljic.json
npm run test
```

### 3. Git으로 버전 관리
```bash
# output 디렉토리는 제외
echo "output/" >> .gitignore
git add data/ templates/ scripts/
git commit -m "Add Session 1 data and templates"
```

---

## 🆘 도움말

### 공식 문서
- **템플릿 가이드**: `docs/TEMPLATE-GUIDE.md`
- **SKILL.md**: 전체 기능 설명
- **html2pptx.md**: HTML→PPTX 변환 가이드

### 커뮤니티
- GitHub Issues: [pptx-mslee/issues](https://github.com/ahfif/pptx-mslee/issues)
- Claude Code 도움말: `/help`

---

**버전**: 2.0.0
**마지막 업데이트**: 2025-01-03
**작성자**: EduPptxBuilder Team
